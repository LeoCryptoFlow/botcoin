# BotCoin (bot) 货币单位系统

## 货币单位

BotCoin的官方货币单位是 **bot**，而非BTC。

### 单位换算
- 1 bot = 1 BotCoin
- 1 bot = 1000 millibot (mbot)
- 1 bot = 1,000,000 microbot (ubot)

### 显示规范
- 主单位: bot
- 符号: B
- 示例: 100 bot 或 100B

### API返回格式
所有涉及金额的API调用均以bot为主单位返回。